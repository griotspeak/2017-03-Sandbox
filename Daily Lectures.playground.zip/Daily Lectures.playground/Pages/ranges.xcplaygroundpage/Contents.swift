(3 ..< 100).contains(4)
