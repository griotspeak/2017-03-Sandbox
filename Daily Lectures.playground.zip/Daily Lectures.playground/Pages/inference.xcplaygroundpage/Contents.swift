let number: Double = 4
let otherNumber = 3.1

number * otherNumber
