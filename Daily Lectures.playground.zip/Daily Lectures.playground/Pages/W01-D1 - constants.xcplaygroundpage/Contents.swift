let daily = 900
let daysPerWeek = 5
let weeksPerMonth = 3
let monthsPerYear: Int = 10

let weekly = daily * daysPerWeek
let monthly = weeksPerMonth * weekly
let yearly =  monthly * monthsPerYear

monthly * monthsPerYear
