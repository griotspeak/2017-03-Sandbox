// And
true && true
true && false
false && false
false && true

// Or
true || true
true || false
false || false
false || true

// Not
!true
!false


